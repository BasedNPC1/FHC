from speechify import Speechify

client = Speechify(
    token="g48E74N0Koi8_3rb93AT9jpP-K29sU4oewDRsfuOTU",
)
client.tts.voices.list()
